<template>
   <div>
        tab
		<ul>
			<li v-for="(item,index) in titles" :class="{'active':curIndex===index}" @click="change(index)">{{item}}</li>
		</ul>
		<component :is="coms[curIndex]"></component>
   </div>
</template>
<script>
//import '../assets/tab.css'

export default {
	props:["titles","contents"],
	created(){
		// this.contents.forEach((item)=>{
		// 	console.log(item)
		// 	this.coms.push({"template":'<div class="nr">'+item+'</div>'}); //每一个字符串转为组件对象了
		// })

		// console.log(this.coms)
	},
	data(){
		return {
			 curIndex:0, //当前项目的索引
			 coms:[] //放数组每一项内容，每一项是一个组件
		}
	},
	methods:{
		change(index){
			this.curIndex=index;
		}
	}
}
</script>

<style>
	ul{
		padding:0;
		margin:0;
		list-style: none;
	}
	ul li{
		display: inline-block;
		width:50px;
	}
	.active{
		color:red;
	}
	.nr{
		width: 300px;
		height: 150px;
		border: 1px solid #000;
	}

</style>