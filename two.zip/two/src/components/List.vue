<template>
   <div>

		<ul>
			<li v-for="item in list">{{item.name}} {{item.age}}</li>
		</ul>
		<input type="text" v-model="name" />
		<input type="text" v-model="age" />
		<button @click="add">添加</button>
   </div>
</template>
<script>
    import axios from 'axios'

    export default {
    	data(){
    		return {
    			list:[],
    			name:'',
    			age:0
    		}
    	},
    	created(){
    		this.getData();
    	},

    	methods:{
    		add(){
    			axios.get("http://localhost:3000/users",{
    				name:this.name,
    				age:this.age
    			},{
    				headers:{                               //post提交一定要写header 信息
    					'Content-type':'application/json'
    				}
    			}).then(()=>{
    				alert("添加成功");
    				this.getData();  //添加成功后，再次拿到新数据
    			})
    		},
    		getData(){
    			axios.get("http://localhost:3000/users").then((res)=>{
    				this.list = res.data;
    		    })
    		}
    	}
    }
</script>