import Vue from 'vue'
import Tab from '@/components/Tab'
import List from '@/components/List'
import VueRouter from 'vue-router';  //1)引用

Vue.use(VueRouter); //2)使用

var router =new VueRouter({  //3）实例化
		routes:[
			{
				path:'/one',
				component:Tab
			},
			{
				path:'/two',
				component:List
			}
		]
})

export default router;