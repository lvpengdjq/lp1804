<template>
  <div id="app">
     
        <router-link to="/one">one</router-link>
        <router-link to="/two">two</router-link>
        <router-view />
  </div>
</template>

<script>

// import "bootstrap/dist/css/bootstrap.css";
export default {
  name: 'App'
  
}
</script>

<style>
#app {

}
</style>
